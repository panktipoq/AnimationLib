//
//  CAAnimationExtension.swift
//  PoqAnimationLib
//
//  Created by Pankti Patel on 16/11/2018.
//  Copyright © 2018 Pankti Patel. All rights reserved.
//

import QuartzCore

extension CAAnimation{
    
    func configure(delay: Double, duration: Double, timingfunction: TimingFunction, isRemovedOnCompletion: Bool = false){
        self.beginTime = delay
        self.duration = duration
        self.timingFunction = timingfunction.rawValue
        self.fillMode = FillMode.forwards.rawValue
        self.isRemovedOnCompletion = isRemovedOnCompletion
  }
}
