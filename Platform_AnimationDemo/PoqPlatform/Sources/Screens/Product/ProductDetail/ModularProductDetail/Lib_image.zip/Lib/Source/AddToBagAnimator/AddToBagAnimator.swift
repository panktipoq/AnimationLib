//
//  AddToBagAnimator.swift
//  PoqAnimationLib
//
//  Created by Pankti Patel on 16/11/2018.
//  Copyright © 2018 Pankti Patel. All rights reserved.
//

import Foundation
import UIKit


struct AddToBagAnimator {
    
    
    static func startAnimation(with settings:AddToBagAnimSettings,
                               completion:@escaping AnimClosure){
        
        let addToBagAnimatorView = AddToBagAnimatorView(frame: UIScreen.main.bounds)
        guard  let window = UIApplication.shared.keyWindow else {
            fatalError("window not found")
        }
        window.addSubview(addToBagAnimatorView)
        addToBagAnimatorView.startAnimation(with: settings,
                                            completion: completion)
        
    }
    static  func stopAnimation(){
        AddToBagAnimatorView.stopAnimation()
    }
    
}
