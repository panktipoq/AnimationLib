//
//  PoqAnimator.swift
//  PoqAnimationLib
//
//  Created by Pankti Patel on 16/11/2018.
//  Copyright © 2018 Pankti Patel. All rights reserved.
//

import UIKit

// Animation Block Definition
public typealias AnimClosure = (() -> Void)

/*
 
 TODO : Add notes here
 Animation Library
 
 */



public class PoqAnimator : NSObject{
    
//    static let shared = PoqAnimator()
    
    override init() {
        super.init()
    }
    public enum AnimationType{
        case sequence
        case parallel
        
    }
    // Initializations
    private var animationGroup = CAAnimationGroup()
    private var animations = [CAAnimation]()
    private var layer : CALayer?
    
    public func addBasicAnimation<T:AnimationValueType>(keyPath:AnimatorKeyPath<T>,
                                                 from: T,
                                                 to: T,
                                                 duration: Double,
                                                 delay: Double = 0,
                                                 timingFunction: TimingFunction = .default) -> Self{
        
        let basicAnimtion = CABasicAnimation(keyPath: keyPath.rawValue)
        basicAnimtion.fromValue = from
        basicAnimtion.toValue = to
        basicAnimtion.configure(delay: delay, duration: duration, timingfunction: timingFunction)
        animations.append(basicAnimtion)
        return self
    }
    public func addKeyFrameAnimation<T:AnimationValueType>(keyPath:AnimatorKeyPath<T>,
                                                    values: [T],
                                                    keyTimes : [NSNumber],
                                                    duration: Double,
                                                    delay: Double = 0,
                                                    timingFunction: TimingFunction = .default) -> Self{
        
        let keyFrameAnimation = CAKeyframeAnimation(keyPath: keyPath.rawValue)
        keyFrameAnimation.values = values
        keyFrameAnimation.keyTimes = keyTimes
        keyFrameAnimation.configure(delay: delay,
                                    duration: duration,
                                    timingfunction: timingFunction,
                                    isRemovedOnCompletion: false)
        animations.append(keyFrameAnimation)
        return self
        
    }
    
    public func startAnimation(for layer:CALayer,
                               type:AnimationType,
                        isRemovedOnCompletion:Bool = false,
                        completion:AnimClosure? = nil){
    
        self.layer = layer
        animationGroup = CAAnimationGroup()
        animationGroup.duration = totalDuration(for: type)
        animationGroup.animations = self.animations
        animationGroup.isRemovedOnCompletion = isRemovedOnCompletion
        animationGroup.fillMode = FillMode.forwards.rawValue
        if type == .sequence{
            calculateBeginTime()
        }
        CATransaction.begin()
        CATransaction.setCompletionBlock(completion)
        layer.add(animationGroup, forKey: UUID().uuidString)
        CATransaction.commit()
    }
    public func stopAnimation(){
        layer?.removeAllAnimations()
        animationGroup = CAAnimationGroup()
        animations = []
    }
}

extension PoqAnimator{
    
    //MARK: - Helpers
    
    func totalDuration(for type:AnimationType) -> Double{
        switch type {
        case .sequence:
            return animations.last.map { $0.beginTime + $0.duration } ?? 0
        case .parallel:
            return animations.map{$0.duration}.reduce(0, +)
        }
    }
    
    func calculateBeginTime(){
        for (index, anim) in animations.enumerated() where index > 0{
            let prevAnim = animations[index-1]
            anim.beginTime += prevAnim.beginTime + prevAnim.duration
        }
    }
}
